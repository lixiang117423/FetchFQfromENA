from .get_fq_file import download_fastq

__all__ = ['download_fastq', 'get_fq_meta']