# FetchFQfromENA

A Python tool to fetch FASTQ files from ENA database

## Installation
```bash
pip install -r requirements.txt
python setup.py install
```

## Usage Example

### get the meta information of a run


## Requirements
- Python 3.7+
- requests>=2.31.0